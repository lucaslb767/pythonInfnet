#Escreva um programa em Python que leia um vetor de 5 números inteiros e mostre-os.

vetor = [1,2,3,4,5]

print(vetor)